'use strict';
const http  = require('http');
const https = require('https');
const net   = require('net');

const PORTA_SERVIDOR = 3333;
const TOKEN          = 'cozinha-rebeca-2026';
const REBECA_URL     = 'https://rebecasistemas.com.br';
let   ADMIN_ID       = null;

// ── Buscar adminId automaticamente ───────────────────────────────
function buscarAdminId() {
  return new Promise((resolve) => {
    const url = `${REBECA_URL}/api/cozinha/admins?token=${TOKEN}`;
    https.get(url, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try {
          const j = JSON.parse(d);
          if (j.admins && j.admins[0]) resolve(j.admins[0]._id);
          else resolve(null);
        } catch { resolve(null); }
      });
    }).on('error', () => resolve(null));
  });
}

// ── Buscar jobs pendentes ─────────────────────────────────────────
function buscarJobs(adminId) {
  return new Promise((resolve) => {
    const url = `${REBECA_URL}/api/cozinha/jobs/${adminId}?token=${TOKEN}`;
    https.get(url, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve(JSON.parse(d).jobs || []); }
        catch { resolve([]); }
      });
    }).on('error', () => resolve([]));
  });
}

// ── Confirmar job impresso ────────────────────────────────────────
function confirmarJob(jobId) {
  return new Promise((resolve) => {
    const url = new URL(`${REBECA_URL}/api/cozinha/jobs/${jobId}/confirmar?token=${TOKEN}`);
    const req = https.request({ hostname: url.hostname, path: url.pathname + url.search, method: 'POST',
      headers: { 'Content-Length': 0 } }, (res) => { res.resume(); resolve(); });
    req.on('error', () => resolve());
    req.end();
  });
}

// ── Imprimir via ESC/POS ─────────────────────────────────────────
function imprimirNaImpressora(ip, porta, texto, mesa) {
  return new Promise((resolve, reject) => {
    const client = new net.Socket();
    const ESC = '\x1B', GS = '\x1D';
    const INIT = ESC+'@', BOLD_ON = ESC+'E\x01', BOLD_OFF = ESC+'E\x00';
    const CENTER = ESC+'a\x01', LEFT = ESC+'a\x00';
    const FONT_GDE = GS+'!\x11', FONT_NOR = GS+'!\x00';
    const FEED = '\n', CUT = GS+'V\x41\x03';
    const hora = new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
    const data = new Date().toLocaleDateString('pt-BR');
    let cmd = INIT + CENTER + BOLD_ON + FONT_GDE + '*** PEDIDO ***' + FEED + FONT_NOR + BOLD_OFF;
    cmd += '========================' + FEED;
    if (mesa) cmd += LEFT + BOLD_ON + 'Mesa: ' + BOLD_OFF + mesa + FEED;
    cmd += LEFT + BOLD_ON + 'Hora: ' + BOLD_OFF + hora + ' ' + data + FEED;
    cmd += '========================' + FEED + LEFT + FEED;
    cmd += texto + FEED + FEED + FEED + CUT;
    client.setTimeout(5000);
    client.connect(porta, ip, () => {
      client.write(cmd, 'binary', () => { client.destroy(); resolve(true); });
    });
    client.on('error', (e) => { console.error('[Impressora] Erro TCP:', e.message); reject(e); });
    client.on('timeout', () => { client.destroy(); reject(new Error('Timeout TCP')); });
  });
}

// ── Polling: buscar e imprimir jobs ──────────────────────────────
let impConfig = { ip: '127.0.0.1', porta: 9100 };

async function buscarConfigImpressora(adminId) {
  return new Promise((resolve) => {
    const url = `${REBECA_URL}/api/cozinha/impressora/${adminId}?token=${TOKEN}`;
    https.get(url, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try {
          const j = JSON.parse(d);
          if (j.impressora) {
            impConfig.ip   = j.impressora.ipImpressora || j.impressora.ip || '127.0.0.1';
            impConfig.porta = j.impressora.portaImpressora || 9100;
            console.log(`[Config] Impressora: ${impConfig.ip}:${impConfig.porta}`);
          }
        } catch {}
        resolve();
      });
    }).on('error', () => resolve());
  });
}

async function polling() {
  if (!ADMIN_ID) {
    ADMIN_ID = await buscarAdminId();
    if (!ADMIN_ID) { setTimeout(polling, 5000); return; }
    console.log('[Polling] AdminId:', ADMIN_ID);
    await buscarConfigImpressora(ADMIN_ID);
  }
  const jobs = await buscarJobs(ADMIN_ID);
  for (const job of jobs) {
    console.log(`[Job] Imprimindo job ${job._id} mesa:${job.mesa||'?'}`);
    try {
      await imprimirNaImpressora(impConfig.ip, impConfig.porta, job.texto, job.mesa);
      await confirmarJob(job._id);
      console.log(`[Job] ✅ Impresso job ${job._id}`);
    } catch(e) {
      console.error(`[Job] ❌ Erro job ${job._id}:`, e.message);
    }
  }
  setTimeout(polling, 2000);
}

// ── Servidor HTTP local (health check) ───────────────────────────
const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }
  res.writeHead(200, {'Content-Type':'application/json'});
  res.end(JSON.stringify({ ok: true, adminId: ADMIN_ID, impressora: impConfig }));
});

server.listen(PORTA_SERVIDOR, '0.0.0.0', () => {
  console.log('');
  console.log('🍽️  REBECA COZINHA - Servidor Local');
  console.log('=====================================');
  console.log(`✅ Rodando na porta ${PORTA_SERVIDOR}`);
  console.log('📡 Conectando ao sistema...');
  console.log('⚠️  Mantenha este terminal aberto!');
  console.log('');
  polling();
});
