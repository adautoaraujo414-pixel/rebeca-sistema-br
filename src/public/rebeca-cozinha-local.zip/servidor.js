'use strict';
const http  = require('http');
const https = require('https');
const net   = require('net');

const PORTA_SERVIDOR = 3333;
const TOKEN          = 'cozinha-rebeca-2026';
const REBECA_URL     = 'https://rebecasistemas.com.br';
let   ADMIN_ID       = null;
let   impConfig      = { ip: '127.0.0.1', porta: 9100 };

function get(url) {
  return new Promise((resolve) => {
    https.get(url, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch { resolve({}); } });
    }).on('error', () => resolve({}));
  });
}

function post(url) {
  return new Promise((resolve) => {
    const u = new URL(url);
    const req = https.request({ hostname: u.hostname, path: u.pathname + u.search,
      method: 'POST', headers: { 'Content-Length': 0 } }, (res) => { res.resume(); resolve(); });
    req.on('error', () => resolve());
    req.end();
  });
}

async function init() {
  const j = await get(`${REBECA_URL}/api/cozinha/admins-local?token=${TOKEN}`);
  if (j.admins && j.admins[0]) {
    ADMIN_ID = j.admins[0].adminId || j.admins[0]._id;
    impConfig.ip    = j.admins[0].ipImpressora || j.admins[0].ip || '127.0.0.1';
    impConfig.porta = j.admins[0].portaImpressora || 9100;
    console.log(`✅ AdminId: ${ADMIN_ID}`);
    console.log(`🖨️  Impressora: ${impConfig.ip}:${impConfig.porta}`);
  } else {
    console.log('⚠️ Não encontrou config — tentando em 10s...');
    setTimeout(init, 10000);
    return;
  }
  polling();
}

async function polling() {
  try {
    const j = await get(`${REBECA_URL}/api/cozinha/jobs/${ADMIN_ID}?token=${TOKEN}`);
    for (const job of (j.jobs || [])) {
      console.log(`[Job] Imprimindo mesa:${job.mesa||'?'} — ${job.texto.substring(0,30)}...`);
      try {
        await imprimir(impConfig.ip, impConfig.porta, job.texto, job.mesa);
        await post(`${REBECA_URL}/api/cozinha/jobs/${job._id}/confirmar?token=${TOKEN}`);
        console.log(`✅ Impresso job ${job._id}`);
      } catch(e) { console.error(`❌ Erro impressão:`, e.message); }
    }
  } catch(e) { console.error('[Polling] Erro:', e.message); }
  setTimeout(polling, 2000);
}

function imprimir(ip, porta, texto, mesa) {
  return new Promise((resolve, reject) => {
    const client = new net.Socket();
    const ESC = '\x1B', GS = '\x1D';
    const INIT=ESC+'@', BON=ESC+'E\x01', BOFF=ESC+'E\x00';
    const CENTER=ESC+'a\x01', LEFT=ESC+'a\x00';
    const FG=GS+'!\x11', FN=GS+'!\x00', FEED='\n', CUT=GS+'V\x41\x03';
    const hora = new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
    const data = new Date().toLocaleDateString('pt-BR');
    let cmd = INIT+CENTER+BON+FG+'*** PEDIDO ***'+FEED+FN+BOFF;
    cmd += '========================'+FEED;
    if (mesa) cmd += LEFT+BON+'Mesa: '+BOFF+mesa+FEED;
    cmd += LEFT+BON+'Hora: '+BOFF+hora+' '+data+FEED;
    cmd += '========================'+FEED+LEFT+FEED;
    cmd += texto+FEED+FEED+FEED+CUT;
    client.setTimeout(5000);
    client.connect(porta, ip, () => { client.write(cmd,'binary',() => { client.destroy(); resolve(); }); });
    client.on('error', reject);
    client.on('timeout', () => { client.destroy(); reject(new Error('Timeout')); });
  });
}

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.writeHead(200, {'Content-Type':'application/json'});
  res.end(JSON.stringify({ ok: true, adminId: ADMIN_ID, impressora: impConfig }));
});

server.listen(PORTA_SERVIDOR, '0.0.0.0', () => {
  console.log('');
  console.log('🍽️  REBECA COZINHA - Servidor Local v3');
  console.log('========================================');
  console.log(`✅ Rodando na porta ${PORTA_SERVIDOR}`);
  console.log('📡 Conectando ao sistema Rebeca...');
  console.log('⚠️  Mantenha este terminal aberto!');
  console.log('');
  init();
});
