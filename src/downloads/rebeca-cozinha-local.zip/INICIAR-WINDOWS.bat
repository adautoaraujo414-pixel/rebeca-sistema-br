@echo off
set PASTA=%~dp0
set STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

copy "%PASTA%rebeca-cozinha.exe" "%STARTUP%\rebeca-cozinha.exe" >nul 2>&1
copy "%PASTA%INICIAR-WINDOWS.bat" "%STARTUP%\INICIAR-WINDOWS.bat" >nul 2>&1

echo Rebeca Cozinha configurado para iniciar com o Windows!
start "" "%PASTA%rebeca-cozinha.exe"
